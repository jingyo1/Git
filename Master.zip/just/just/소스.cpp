#include <stdio.h>
int main()
{
	printf("hi");
	return 0;
}